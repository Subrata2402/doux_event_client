import './App.css';
import Routing from './components/routing';

function App() {

  return (
    <Routing />
  )
}

export default App;
